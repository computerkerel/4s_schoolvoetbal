﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace _4sgokken
{
    public partial class Login : _4sgokken.Form1
    {
        public Login()
        {
            InitializeComponent();
        }
    }
}
